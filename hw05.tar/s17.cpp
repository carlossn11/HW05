//
// Created by Carlos Aguilera on 3/5/20.
//

#include "hw05.h"

int main() {
    int d[5][8] = { {3,4,5,3,5,6,7,54},
                    {2,53,5,4,3,6,5,4},
                    {5,6,4,3,8,3,97,4},
                    {43,3,6,4,3,7,4,3},
                    {76,5,3,7,4,8,4,1} };
    int s;
// i n i t i a l i z e ∗d
    s = Sum(d);
    return 0;
}
