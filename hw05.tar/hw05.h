//
// Created by Carlos Aguilera on 3/5/20.
//

#ifndef HW05_HW05_H
#define HW05_HW05_H

#include <iostream>

using namespace std;

int Sum(int *p, int k);
int Sum(int A[5]);
int Sum(int A[][8]);
int Sum(int *A[], int r);
int Sum(int **p,int r,int c);
int Sum(int *p,int r,int c);


#endif //HW05_HW05_H
