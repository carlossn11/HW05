//
// Created by Carlos Aguilera on 3/5/20.
//

#include "hw05.h"

int main() {
    int d[5] = {1,2,3,4,5};
    int s;
// i n i t i a l i z e d [ ]
    s = Sum(d,5);
    cout << "s: " << s;
    return 0;
}